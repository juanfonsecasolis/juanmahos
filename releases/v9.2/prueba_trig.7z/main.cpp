#include <stdio.h>
#include <time.h>
#include "matematica.h"

//extern "C" double* calcularCos(double* angulo);

double pi = 3.14159265;

double seno_asm(double radianes);
double coseno_asm(double radianes);
void demo();
void prueba_asm(int max);
void prueba_taylor(int max);

int main(){
	//demo();
	int max = 360000000;
	prueba_asm(max);
	prueba_taylor(max);
}

void demo(){
	double cos,sen,inp=180,conv_ant;

	/*usando las series de Taylor*/
	conv_ant = gradosARadianes(inp);
	sen = seno(conv_ant);
	cos = coseno(conv_ant);
	printf("TAYLOR: {sen,cos}(%f) = {%f,%f}\n",inp,sen,cos);
	
	/*usando las funciones en ensablador*/
	sen = seno_asm(inp);
	cos = coseno_asm(inp);
	printf("ASM: {sen,cos}(%f) = {%f,%f}\n",inp,sen,cos);
}

void prueba_asm(int max){
	double inicio,fin,conv_ant; //cps : clock per second
	inicio = (double) clock();
	
	/*hacemos prueba de 0 a 180 con el metodo Taylor*/
	for(int grados=0;grados<max;grados++){
		conv_ant = mod((grados/180)*pi,360.0);
		seno_asm(conv_ant);
		coseno_asm(conv_ant);
	}
	
	fin = (double) clock() - inicio;
	printf("ASM: %f\n",fin/CLOCKS_PER_SEC);
}

void prueba_taylor(int max){
	double inicio,fin,conv_ant; //cps : clock per second
	inicio = (double) clock();
	
	/*hacemos prueba de 0 a 180 con el metodo Taylor*/
	for(int grados=0;grados<max;grados++){
		conv_ant = mod((grados/180)*pi,360.0);
		seno(conv_ant);
		coseno(conv_ant);
	}
	
	fin = (double) clock() - inicio;
	printf("TAYLOR: %f\n",fin/CLOCKS_PER_SEC);
}

double seno_asm(double radianes){
	double resultado;
	__asm__("fsin" :"=t" (resultado) : "0" (radianes));
	return resultado;
}

double coseno_asm(double radianes){
	double resultado;
	__asm__("fcos" :"=t" (resultado) : "0" (radianes));
	return resultado;
}

