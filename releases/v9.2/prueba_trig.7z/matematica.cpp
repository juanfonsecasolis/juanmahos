/*	
	=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	=- Juanma Hyper Operative System (juanmaHOS) Copyright 2011 Juan M. Fonseca, juanma2268@gmail.com							
	=- File: matematica.cpp											
	=- Nota: Patlabor is property of Bandai, i'm just a fan! :)		 
	=- Last update: 24/02/2011			
	=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	
	This file is part of Foobar.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "matematica.h"

int techo(double x){
	double decimales = x - ((int) x);
	int retorno;
	if(decimales > 0.5){
		retorno = x+1;
	}else{
		retorno = x;
	}
	return retorno;
}

double mod(double x,double y){
	if(x < y){ return x; }
	return ( x - ((int)(x/y))*y );
}

double gradosARadianes(double x){
	double pi = 3.141592654;
	return pi/180 * x;
}

/*
	Algoritmo babilonico, wiki:
	
	El algoritmo babil�nico se centra en el hecho de que cada lado de un cuadrado 
	es la ra�z cuadrada del �rea. Fue usado durante muchos a�os para calcular ra�ces 
	cuadradas a mano debido a su gran eficacia y rapidez. Para calcular una ra�z, 
	dibuje un rect�ngulo cuya �rea sea el n�mero al que se le busca ra�z y luego aproxime 
	la base y la altura del rect�ngulo hasta formar o por lo menos aproximar un cuadrado.
*/
double raizCuadrada(double x){
    double r = x, t = 0;
    while (t != r){
        t = r;
        r = (x/r + r)/2;
    }
    return r;
	//return 1.4142;
}

double potencia(double base,int exponente){
	double suma=1;
	for(int i=0;i<exponente;i++){
		suma *= base;
	}
	return suma;
}

double factorial(int x){
	double fact = 1;
	for(int i=x;i>0;i--){
		fact *= i;
	}
	return fact;
}

/*
	Aproximacion de funcion Seno usando potencias de Taylor.
	Requiere: x en radianes
*/
double seno(double x){
	double suma=0;
	for(int i=0;i<presicionTaylor;i++){
		suma += potencia(-1,i) * potencia(x,2*i+1) * (1.0/(factorial(2*i+1))); 
	}
	return suma;
}

/*
	Aproximacion de funcion CoSeno usando potencias de Taylor.
	Requiere: x en radianes
*/
double coseno(double x){
	double suma=0;
	for(int i=0;i<presicionTaylor;i++){
		suma += potencia(-1,i) * potencia(x,2*i) * (1.0/(factorial(2*i))); 
	}
	return suma;
}

